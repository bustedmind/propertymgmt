cd ReactJS
rm calculate-score.js
npm install
echo "React installation is done"
cd ../NodeJS/
npm install;
echo "Nodejs installation is done"
node src/mongoose/db/defaultDB.js
echo "Mongodb setup is done"
echo "All installations and setup are done. You are ready to go ahead!!!"
