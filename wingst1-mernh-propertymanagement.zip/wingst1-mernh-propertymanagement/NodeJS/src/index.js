const app = require("./app");

//serving on port 8000
app.listen(8000, () => console.log("App is running on port 8000"));
